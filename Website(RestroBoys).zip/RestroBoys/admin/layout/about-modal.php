<div id="modal1" class="modal">
    <div class="modal-content">
      <h4>About RestroBoys</h4>
      <p>We are RestroBoys. One Resturant powered by the Boys only! We love to make delicious foods and serve our customers. We have been doing this for many years now!</p>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>